{
  "name": "Human",
  "slug": "human",
  "version": "1.0.2",
  "widget-areas": [
  	"widgets-area-a",
  	"widgets-area-b"
  ]
}